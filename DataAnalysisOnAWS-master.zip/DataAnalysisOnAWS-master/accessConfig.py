consumer_key = 't70JdJ7pE5E7STs7CY6aF9RYZ'
consumer_secret = 'vP2PXs5tOnPhRCI4giCZU544yfDbgs0o7XpDIM42VtvPUtNhOT'
access_token = '3183555540-RdwH6jyQzgTEa5ptfeLiA1JaUop1XlsgaPZfL8B'
access_secret = 'i1GS4fQtRTdpWZ8pMkv8lyqzwzmfXxWbD5P9IhWlIU5nl'
